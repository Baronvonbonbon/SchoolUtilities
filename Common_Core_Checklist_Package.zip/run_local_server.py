import http.server, socketserver, os, webbrowser

PORT = 8000
class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        super().end_headers()

if __name__ == "__main__":
    os.chdir(os.path.dirname(__file__) or ".")
    url = f"http://localhost:{PORT}/Common_Core_All_Grades_Checklist_Columns_Evidence_CCR_Under_Header.html"
    print("Serving at", url)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down...")
